package com.example.pokemonlist;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class PokemonModel implements Parcelable {
    private String mName;
    private int mHeight;
    private int mWeight;
    private int mOrderNumber;
    private String mUrl;

    public PokemonModel() {
    }

    protected PokemonModel(Parcel in) {
        mName = in.readString();
        mHeight = in.readInt();
        mWeight = in.readInt();
        mOrderNumber = in.readInt();
        mUrl = in.readString();
    }

    public static final Creator<PokemonModel> CREATOR = new Creator<PokemonModel>() {
        @Override
        public PokemonModel createFromParcel(Parcel in) {
            return new PokemonModel(in);
        }

        @Override
        public PokemonModel[] newArray(int size) {
            return new PokemonModel[size];
        }
    };

    public String getName() {
        return mName;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public int getHeight() {
        return mHeight;
    }

    public void setHeight(int mHeight) {
        this.mHeight = mHeight;
    }

    public int getWeight() {
        return mWeight;
    }

    public void setWeight(int mWeight) {
        this.mWeight = mWeight;
    }

    public int getOrderNumber() {
        return mOrderNumber;
    }

    public void setOrderNumber(int mOrderNumber) {
        this.mOrderNumber = mOrderNumber;
    }

    public String getUrl() {
        return mUrl;
    }

    public void setUrl(String mUrl) {
        this.mUrl = mUrl;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mName);
        parcel.writeInt(mHeight);
        parcel.writeInt(mWeight);
        parcel.writeInt(mOrderNumber);
        parcel.writeString(mUrl);
    }
}
