package com.example.pokemonlist;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PokemonDetailsActivity extends AppCompatActivity {

    private TextView orderNumberTextView;
    private TextView nameTextView;
    private TextView heightTextView;
    private TextView weightTextView;
    private ViewGroup mLoading;

    private String mUrl;

    private PokemonModel pokemonModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokemon_details);

        orderNumberTextView = findViewById(R.id.mOrderNumber);
        nameTextView = findViewById(R.id.name);
        heightTextView = findViewById(R.id.mHeight);
        weightTextView = findViewById(R.id.mWeight);
        mLoading = findViewById(R.id.loadingLayout2);

        pokemonModel = getIntent().getParcelableExtra("POKEMON");

        mUrl = pokemonModel.getUrl();

        new GetData().execute();
    }

    private class GetData extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (mLoading != null) {
                mLoading.setVisibility(View.VISIBLE);
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            HttpURLConnection urlConnection = null;
            BufferedReader bufferedReader = null;

            try {
                // Loading JSON from the Web URL
                URL url = new URL(mUrl);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }

                if (stringBuilder.length() == 0) {
                    return null;
                } else {
                    return stringBuilder.toString();
                }

            } catch (IOException e) {
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (bufferedReader != null) {
                    try {
                        bufferedReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        @Override
        protected void onPostExecute(String jsonStr) {
            super.onPostExecute(jsonStr);

            if (jsonStr != null) {

                try {
                    JSONObject jsonObject = new JSONObject(jsonStr);

                    pokemonModel.setName(jsonObject.getString("name"));
                    pokemonModel.setOrderNumber(jsonObject.getInt("order"));
                    pokemonModel.setWeight(jsonObject.getInt("weight"));
                    pokemonModel.setHeight(jsonObject.getInt("height"));

                    updateData();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            if (mLoading != null) {
                mLoading.setVisibility(View.GONE);
            }
        }
    }

    /**
     * Updates the selected pokemon with the recently obtained details.
     */
    public void updateData() {
        orderNumberTextView.setText(String.valueOf(pokemonModel.getOrderNumber()));
        heightTextView.setText(String.valueOf(pokemonModel.getHeight()));
        weightTextView.setText(String.valueOf(pokemonModel.getWeight()));
        nameTextView.setText(pokemonModel.getName());
    }
}