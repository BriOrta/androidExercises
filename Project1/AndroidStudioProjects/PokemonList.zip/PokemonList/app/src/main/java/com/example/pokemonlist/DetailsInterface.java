package com.example.pokemonlist;

public interface DetailsInterface {
    /**
     * Shows the details of the item clicked.
     *
     * @param position position index of the item.
     */
    void onItemClick(final int position);
}
