package com.example.pokemonlist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PokemonAdapter extends RecyclerView.Adapter<PokemonAdapter.ViewHolder> {

    private final Context mContext;
    private final ArrayList<PokemonModel> mPokemonModelArrayList;
    private final DetailsInterface mDetailsInterface;

    public PokemonAdapter(Context context, ArrayList<PokemonModel> pokemonModels, DetailsInterface detailsInterface) {
        this.mContext = context;
        this.mPokemonModelArrayList = pokemonModels;
        this.mDetailsInterface = detailsInterface;
    }

    @NonNull
    @Override
    public PokemonAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate viewHolder which will give a look to all the  rows through the layout
        final LayoutInflater inflater = LayoutInflater.from(mContext);
        final View view = inflater.inflate(R.layout.recycler_view_row, parent, false);

        return new PokemonAdapter.ViewHolder(view, mDetailsInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull PokemonAdapter.ViewHolder holder, int position) {
        // Assign values to each of the items as they come into the screen based on their position
        holder.nameTextView.setText(mPokemonModelArrayList.get(position).getName());
    }

    @Override
    public int getItemCount() {
        // Know how many items will be displayed
        return mPokemonModelArrayList.size();
    }

    /**
     * Updates the recycler view with the new data.
     *
     * @param pokemonModelList list of pokemons.
     */
    public void updateData(ArrayList<PokemonModel> pokemonModelList) {
        if (pokemonModelList.size() > 0) {
            notifyDataSetChanged();
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final TextView nameTextView;

        public ViewHolder(@NonNull View itemView, DetailsInterface detailsInterface) {
            // Get views from the layout to create each of the items
            super(itemView);
            nameTextView = itemView.findViewById(R.id.mPokemonName);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (detailsInterface != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            detailsInterface.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
