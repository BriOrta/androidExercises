package com.example.pokemonlist;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements DetailsInterface {

    private final ArrayList<PokemonModel> mPokemonModels = new ArrayList<>();
    private PokemonAdapter mPokemonAdapter;
    private ViewGroup mLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mLoading = findViewById(R.id.loadingLayout);

        RecyclerView recyclerView = findViewById(R.id.mRecyclerView);
        mPokemonAdapter = new PokemonAdapter(this, mPokemonModels, this);
        recyclerView.setAdapter(mPokemonAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        new GetData().execute();
    }

    @Override
    public void onItemClick(int position) {
        Intent detailsIntent = new Intent(MainActivity.this, PokemonDetailsActivity.class);
        detailsIntent.putExtra("POKEMON", mPokemonModels.get(position));
        startActivity(detailsIntent);
    }

    private class GetData extends AsyncTask<Void, Void, ArrayList<String>> {

        private String jsonUrl = "https://pokeapi.co/api/v2/pokemon/";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (mLoading != null) {
                mLoading.setVisibility(View.VISIBLE);
            }
        }

        @Override
        protected ArrayList<String> doInBackground(Void... voids) {
            HttpURLConnection urlConnection = null;
            BufferedReader bufferedReader = null;
            ArrayList<String> jsonStringsList = new ArrayList<>();

            int count = 0;

            try {
                // Loading JSON from the Web URL
                while (count < 1281) {
                    URL url = new URL(jsonUrl);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.connect();


                    InputStream inputStream = urlConnection.getInputStream();
                    bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;

                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }

                    count += 20;
                    jsonUrl = "https://pokeapi.co/api/v2/pokemon/?offset=" + count + "&limit=20";

                    if (stringBuilder.length() != 0) {
                        jsonStringsList.add(stringBuilder.toString());
                    }
                }

                return jsonStringsList;

            } catch (IOException e) {
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (bufferedReader != null) {
                    try {
                        bufferedReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        @Override
        protected void onPostExecute(ArrayList<String> jsonStringsList) {
            super.onPostExecute(jsonStringsList);

            for (final String jsonStr : jsonStringsList) {
                if (jsonStr != null) {

                    try {
                        JSONObject rootJsonObject = new JSONObject(jsonStr);
                        JSONArray resultsJsonArray = rootJsonObject.getJSONArray("results");

                        for (int i = 0; i < resultsJsonArray.length(); i++) {

                            JSONObject jsonObject = resultsJsonArray.getJSONObject(i);

                            PokemonModel pokemon = new PokemonModel();

                            pokemon.setName(jsonObject.getString("name"));
                            pokemon.setUrl(jsonObject.getString("url"));

                            mPokemonModels.add(pokemon);
                        }

                        if (mPokemonModels.size() > 0) {
                            //Replace RecyclerView Adapter Data
                            mPokemonAdapter.updateData(mPokemonModels);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            if (mLoading != null) {
                mLoading.setVisibility(View.GONE);
            }
        }

    }

}